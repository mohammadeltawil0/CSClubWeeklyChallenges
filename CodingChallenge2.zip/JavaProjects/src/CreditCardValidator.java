import java.util.Scanner;

public class CreditCardValidator {
    public static void main(String[] args) {
    	
    	//Create input
    	
        Scanner input = new Scanner(System.in);
        try {
            // Prompt the user to enter their credit card number
            System.out.print("Enter your credit card number: ");
            String cardNumber = input.nextLine();
            
            // Check if the entered credit card number is valid
            if (isValidCreditCardNumber(cardNumber)) {
                // Determine the type of credit card based on the card number prefix
                if (isAmericanExpress(cardNumber)) {
                    System.out.println("Valid American Express card number");
                } else if (isMasterCard(cardNumber)) {
                    System.out.println("Valid MasterCard card number");
                } else if (isVisa(cardNumber)) {
                    System.out.println("Valid Visa card number");
                } else {
                    // If the card number is valid but not recognized as any specific type
                    System.out.println("Valid credit card number, but not recognized");
                }
            } else {
                // If the entered credit card number is invalid
                System.out.println("Invalid credit card number");
            }
        } catch (Exception e) {
            // Catch any exceptions that might occur during execution and print an error message
            System.out.println("An error occurred: " + e.getMessage());
        } finally {
            // Close the input to release system resources
            input.close();
        }
    }

    // Method to validate a credit card number using the Luhn algorithm
    public static boolean isValidCreditCardNumber(String cardNumber) {
        int sum = 0;
        boolean doubleDigit = false;
        
        // Iterate through each digit of the card number
        for (int i = cardNumber.length() - 1; i >= 0; i--) {
            int digit = Character.getNumericValue(cardNumber.charAt(i));
            
            // Double every other digit, starting from the second-to-last digit
            if (doubleDigit) {
                digit *= 2;
                if (digit > 9) {
                    digit = digit % 10 + digit / 10;
                }
            }
            
            // Add the digit (after doubling if necessary) to the sum
            sum += digit;
            doubleDigit = !doubleDigit;
        }
        
        // If the sum is divisible by 10, the card number is valid
        return sum % 10 == 0;
    }

    // Method to check if the credit card number belongs to American Express
    public static boolean isAmericanExpress(String cardNumber) {
        return cardNumber.length() == 15 && (cardNumber.startsWith("34") || cardNumber.startsWith("37"));
    }

    // Method to check if the credit card number belongs to MasterCard
    public static boolean isMasterCard(String cardNumber) {
        return cardNumber.length() == 16 && (cardNumber.startsWith("51") || cardNumber.startsWith("52") || cardNumber.startsWith("53") || cardNumber.startsWith("54") || cardNumber.startsWith("55"));
    }

    // Method to check if the credit card number belongs to Visa
    public static boolean isVisa(String cardNumber) {
        return (cardNumber.length() == 13 || cardNumber.length() == 16) && cardNumber.startsWith("4");
    }
}

/*
 * Results:
 * Enter your credit card number: 4003600000000014
 * Valid Visa card number
 */