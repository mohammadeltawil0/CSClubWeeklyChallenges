/*
 * Mohammad El-Tawil
 * Computer Science Club
 * Coding Challenge 1
 */

//import scanner
import java.util.Scanner;

public class ColemanLiauIndex {

	/** Main method */
    public static void main(String[] args) {
	
		//Create scanner
        Scanner input = new Scanner(System.in);
        
        //Ask user to input text
        System.out.println("Welcome to the Coleman-Liau Index Calculator!");
        System.out.println("Please enter a text: ");
        String text = input.nextLine();
        
        //Initialize variables
        double letters = computeTotalLetters(text);
        double words = computeTotalWords(text);
        double sentences = computeTotalSentences(text);
        double L = (letters / words) * 100;
        double S = (sentences / words) * 100;
        double index = 0.0588 * L - 0.296 * S - 15.8;
        
        //Display index
        System.out.println("Coleman-Liau Index: " + index);
        computeColemanLiauIndex(index);
        
        //Close scanner
        input.close();
    }
    
    //Method for finding the total number of letters in the text
    public static int computeTotalLetters(String text) {
        int count = 0;
        for (char c : text.toCharArray()) {
            if (Character.isLetter(c)) {
                count++;
            }
        }
        return count;
    }
    
    //Method for finding the total number of words in the text
    public static int computeTotalWords(String text) {
        String[] words = text.split("\\s+");
        return words.length;
    }
    
    //Method for finding the total number of sentences in the text
    public static int computeTotalSentences(String text) {
        String[] sentences = text.split("([.!?])");
        return sentences.length;
    }
    
    //Method for computing the Coleman-Liau Index
    public static void computeColemanLiauIndex(double index) {
        if (index < 1) {
            System.out.println("This text is very easy to read (Grade 1 or lower).");
        } 
        else if (index >= 16) {
            System.out.println("This text is very difficult to read (College level or higher).");
        } 
        else {
            int grade = (int) Math.round(index);
            System.out.println("This text is approximately at a " + grade + "th-grade reading level.");
        }
    }
}

